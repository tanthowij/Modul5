package com.tanthowi.mymaps.app;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng skl1 = new LatLng(-8.5994686, 116.1240867);
        mMap.addMarker(new MarkerOptions().position(skl1).title("SDN 23 Cakranegara"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(skl1, 18));

        LatLng skl2 = new LatLng(-8.6011447, 116.1335881);
        mMap.addMarker(new MarkerOptions().position(skl2).title("SMPN 5 Mataram"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(skl2, 18));

        LatLng skl3 = new LatLng(-8.6062467, 116.1113882);
        mMap.addMarker(new MarkerOptions().position(skl3).title("SMPN 7 Mataram"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(skl3, 18));

        LatLng skl4 = new LatLng(-8.6095087, 116.1194218);
        mMap.addMarker(new MarkerOptions().position(skl4).title("SMAN 4 Mataram"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(skl4, 18));

        LatLng skl5 = new LatLng(-8.5805938, 116.1425532);
        mMap.addMarker(new MarkerOptions().position(skl5).title("SMAN 6 MAtaram"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(skl5, 18));

        LatLng rumah = new LatLng(-8.6025653, 116.1258813);
        mMap.addMarker(new MarkerOptions().position(rumah).title("Your Location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(rumah, 18));
    }
}
